clc
clear all
close all

Ts = 0.1;
t = 0:Ts:1000;           %Generovani casoveho vektoru
N = length(t);
u = idinput(N, 'prbs',[0 0.1], [-1 1]); %PRBS - delka max impulsu Tmax větsi nez doba nabehu Tn (Tmax = pocet posuvnych registru v generatoru PRBS (=n) * Tvz)
y = cviceni02_1(u,t);   %Odezva systemu na vstupni data

% Zobrazeni vstupu a odezvy systemu
figure(1)
plot(t, u, t, y);
title('zmerena odezva systemu')
hold on

% Nachystani Phi, Th a Y pro model systemu 1. radu
k = 2:length(u);
Phi = [-y(k-1), u(k-1)];
Th = [0; 0]; % [a b]
Y = y(k);

% Vypocet MNC a ziskani parametru modelu systemu 1. radu
Th = Phi\Y;     % 1. moznost s pseudoinverzi
Th1 = (Phi'*Phi)^(-1)*Phi'*Y;   % 2. moznost
a = Th(1,1); b = Th(2,1);

% Vypocet odezvy identifikovaneho systemu na vstupni signal u
% 1.zpusob - odpovida vice pocitani na papire - nazornejsi, tento budu chtit v projektu
y_id = zeros(size(u));
for k = 2:length(u)
    y_id(k) = -a*y_id(k-1)+b*u(k-1);   % model 1. radu s identifikovanymi parametry systemu a,b
end

% 2. zpusob pomoci funkce lsim
% Fz = tf([0 b], [1 a], Ts,'Variable', 'z^-1' )
% y_id2 = lsim(Fz,u,t);


% Zobrazeni odezvy identifikovanho modelu
plot(t, y_id);
legend('vstup u', 'vystup y', 'vystup y_id');