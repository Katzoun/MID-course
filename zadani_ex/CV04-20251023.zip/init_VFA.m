clc

Ts = 125e-6;
A = ;       % DOPLNIT
f = ;       % DOPLNIT
offset = 6;